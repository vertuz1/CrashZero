import requests
import time
import random

BOT_TOKEN = '7479788872:AAGm5sCbLhDDnq3OC5tQHbO-LHKiS3wejzA'
CHAT_ID = '7479788872'
API_URL = 'https://drgns8.casino/srv/api/v1/crash/state'

def get_crash_data():
    try:
        response = requests.get(API_URL)
        return response.json()
    except:
        return None

def predict_next(multiplier_history):
    if len(multiplier_history) < 3:
        return round(random.uniform(1.5, 2.0), 2)
    avg = sum(multiplier_history[-3:]) / 3
    fluctuation = random.uniform(-0.2, 0.2)
    return round(avg + fluctuation, 2)

def send_message(text):
    url = f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage'
    data = {'chat_id': CHAT_ID, 'text': text}
    requests.post(url, data=data)

multiplier_history = []

send_message("🤖 Бот запущен и наблюдает за Crash Game!")

while True:
    data = get_crash_data()
    if data and 'crash_point' in data:
        crash_point = data['crash_point']
        if crash_point not in multiplier_history:
            multiplier_history.append(crash_point)
            send_message(f"💥 Коэффициент: x{crash_point}")
            prediction = predict_next(multiplier_history)
            send_message(f"📈 Прогноз на следующий раунд: x{prediction}")
    time.sleep(3)
